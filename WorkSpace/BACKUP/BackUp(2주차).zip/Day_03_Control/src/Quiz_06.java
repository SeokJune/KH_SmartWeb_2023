
public class Quiz_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Hello Java while
		int cnt = 0;
		
		while(cnt < 13) {
			System.out.println("Hello Java while");
			cnt++;
		}

	}

}
