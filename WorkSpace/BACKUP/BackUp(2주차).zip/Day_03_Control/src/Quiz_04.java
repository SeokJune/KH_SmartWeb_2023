
public class Quiz_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 100���� 1���� ���
		int i = 100;
		
		while(i > 0) {
			System.out.println("i = " + i--);
		}
		
	}

}
