
public class Exam_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 10;
		int b = 20;
		
		System.out.println(a + " : " + b);
		
		// swap ���
		// tmp = temporary (�Ͻ�����)
		int tmp = a;
		a = b;
		b = tmp;
		
		System.out.println(a + " : " + b);

	}

}
