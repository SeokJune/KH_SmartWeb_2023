public class Exam_01 {
	public static void main(String[] args) {
		//Promotion
		byte a = 10;
		short b = a;
	}
}
