
public class Quiz_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 10;
		int b = 20;
		
		System.out.println(++a == 10 && b++ == 20);
		System.out.println(a + " : " + b);
		
	}

}
