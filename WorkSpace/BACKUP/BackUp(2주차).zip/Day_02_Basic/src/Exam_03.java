
public class Exam_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte b = 10;
		char ch = 'A';
		int i = 100;
		long l = 1000L;
		
		b = (byte) i;
		ch = (char) b;
		short s = (short) ch;
		float f = l;
		i = ch;
	}

}
