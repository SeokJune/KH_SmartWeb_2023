
public class Exam_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i1 = 10;
		int i2 = 20;
		float f1 = 3.14f;
		char c1 = 'A';
		char c2 = 'B';
		
		System.out.println("��� : " + i1 + i2);
		System.out.println("��� : " + (i1 + i2));
		System.out.println("��� : " + i1 + f1);
		System.out.println("��� : " + (i1 + f1));
		System.out.println("��� : " + f1 + c1);
		System.out.println("��� : " + (f1 + c1));
		System.out.println("��� : " + c1 + c2);
		System.out.println("��� : " + (c1 + c2));
		
	}

}
