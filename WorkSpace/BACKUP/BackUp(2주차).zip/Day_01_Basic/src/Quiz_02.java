public class Quiz_02 {
	public static void main(String[] args) {
		// 3-1
		int num1 = 1325;
		int num2 = 9327;
		System.out.println(num1 * num2);
		
		// 3-2
		long num3 = 10000000000L + 5000;
		System.out.println(num3);
		
		// 3-3
		char c1 = 'A';
		char c2 = 'B';
		System.out.println(c1 + "" + c2);
		System.out.printf("%c%c", c1, c2);
		
	}
}
