public class Quiz_01 {
	public static void main(String[] args) {
		System.out.println("====================");
		System.out.println("        /)/)        ");
		System.out.println("       (  ..)       ");
		System.out.println("       (  >��        ");
		System.out.println("  Have a Good Time. ");
		System.out.println("====================");
	}
}
